package com.androidbackup.app.data.local

import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.androidbackup.app.data.local.database.BackupDatabase
import com.androidbackup.app.data.local.entity.AppSettingsEntity
import com.androidbackup.app.data.local.entity.BackupFolderEntity
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/**
 * Test di migrazione Room Database da Schema v1 a Schema v2 (Fase 1B.1 - Revisione Finale).
 *
 * Utilizza la definizione ESATTA e rigorosa dello schema Versione 1 definita in:
 * app/schemas/com.androidbackup.app.data.local.database.BackupDatabase/1.json:
 * - identity_hash v1: '8e3c54d24f7b6adbc4594c96a324901f'
 * - app_settings: id INTEGER NOT NULL PRIMARY KEY, last_modified_timestamp INTEGER NOT NULL, ecc.
 * - exclusion_patterns: pattern TEXT NOT NULL PRIMARY KEY, position INTEGER NOT NULL.
 *
 * Dimostra:
 * 1. Creazione dello schema v1 identico all'export Room ufficiale.
 * 2. Esecuzione di BackupDatabase.MIGRATION_1_2 a livello SQLite nativo.
 * 3. Conservazione integrale di tutte le impostazioni v1 e pattern v1.
 * 4. Creazione della tabella backup_folders con tutti i campi previsti e indice univoco su tree_uri.
 * 5. Apertura formale del database migrato tramite Room.databaseBuilder() con addMigrations(MIGRATION_1_2).
 * 6. Validazione dello schema da parte del runtime di Room senza eccezioni di mismatch.
 * 7. Piena operatività dei DAO (SettingsDao e FolderDao) sul database migrato.
 */
@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE)
class DatabaseMigrationTest {

    private lateinit var context: Context
    private lateinit var dbFile: File
    private lateinit var openHelper: SupportSQLiteOpenHelper
    private lateinit var db: SupportSQLiteDatabase
    private var roomDatabase: BackupDatabase? = null

    // Schema SQL ESATTO estratto da 1.json
    private val v1AppSettingsSql = """
        CREATE TABLE IF NOT EXISTS `app_settings` (
            `id` INTEGER NOT NULL,
            `frequency` TEXT NOT NULL,
            `network_policy` TEXT NOT NULL,
            `reserve_space_mb` INTEGER NOT NULL,
            `fifo_rotation_enabled` INTEGER NOT NULL,
            `allow_cloud_only_eviction` INTEGER NOT NULL,
            `require_charging` INTEGER NOT NULL,
            `last_modified_timestamp` INTEGER NOT NULL,
            PRIMARY KEY(`id`)
        )
    """.trimIndent()

    private val v1ExclusionPatternsSql = """
        CREATE TABLE IF NOT EXISTS `exclusion_patterns` (
            `pattern` TEXT NOT NULL,
            `position` INTEGER NOT NULL,
            PRIMARY KEY(`pattern`)
        )
    """.trimIndent()

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext<Context>()
        dbFile = context.getDatabasePath("test_migration.db")
        if (dbFile.exists()) {
            dbFile.delete()
        }

        val config = SupportSQLiteOpenHelper.Configuration.builder(context)
            .name("test_migration.db")
            .callback(object : SupportSQLiteOpenHelper.Callback(1) {
                override fun onCreate(sqLiteDb: SupportSQLiteDatabase) {
                    // Crea esattamente lo schema v1 ufficiale (1.json)
                    sqLiteDb.execSQL(v1AppSettingsSql)
                    sqLiteDb.execSQL(v1ExclusionPatternsSql)
                    sqLiteDb.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY, identity_hash TEXT)")
                    sqLiteDb.execSQL("INSERT OR REPLACE INTO room_master_table (id, identity_hash) VALUES(42, '8e3c54d24f7b6adbc4594c96a324901f')")
                }

                override fun onUpgrade(
                    sqLiteDb: SupportSQLiteDatabase,
                    oldVersion: Int,
                    newVersion: Int
                ) {
                    // Gestito nei test specifici
                }
            })
            .build()

        openHelper = FrameworkSQLiteOpenHelperFactory().create(config)
        db = openHelper.writableDatabase
    }

    @After
    fun tearDown() {
        if (roomDatabase != null && roomDatabase!!.isOpen) {
            roomDatabase!!.close()
        }
        if (::db.isInitialized && db.isOpen) {
            db.close()
        }
        if (::openHelper.isInitialized) {
            openHelper.close()
        }
        if (::dbFile.isInitialized && dbFile.exists()) {
            dbFile.delete()
        }
    }

    @Test
    fun testMigration1To2PreservesSettingsAndCreatesBackupFoldersTableWithUniqueIndex() {
        val testTimestamp = 1730000000000L

        // 1. Popola il database v1 con record reali coerenti con 1.json
        db.execSQL("""
            INSERT INTO app_settings (
                id, frequency, network_policy, reserve_space_mb,
                fifo_rotation_enabled, allow_cloud_only_eviction, require_charging, last_modified_timestamp
            ) VALUES (
                ${AppSettingsEntity.DEFAULT_ID}, 'FORTY_EIGHT_HOURS', 'ANY_NETWORK', 250,
                1, 0, 1, $testTimestamp
            )
        """.trimIndent())

        db.execSQL("INSERT INTO exclusion_patterns (pattern, position) VALUES ('cache', 0)")
        db.execSQL("INSERT INTO exclusion_patterns (pattern, position) VALUES ('*.tmp', 1)")
        db.execSQL("INSERT INTO exclusion_patterns (pattern, position) VALUES ('.thumbnails', 2)")

        // 2. Esegui la migrazione ufficiale MIGRATION_1_2
        BackupDatabase.MIGRATION_1_2.migrate(db)

        // 3. Verifica che i dati di app_settings siano rimasti intatti al 100%
        val settingsCursor = db.query("SELECT * FROM app_settings WHERE id = ${AppSettingsEntity.DEFAULT_ID}")
        assertTrue("Il record app_settings deve esistere dopo la migrazione", settingsCursor.moveToFirst())
        assertEquals(AppSettingsEntity.DEFAULT_ID, settingsCursor.getInt(settingsCursor.getColumnIndexOrThrow("id")))
        assertEquals("FORTY_EIGHT_HOURS", settingsCursor.getString(settingsCursor.getColumnIndexOrThrow("frequency")))
        assertEquals("ANY_NETWORK", settingsCursor.getString(settingsCursor.getColumnIndexOrThrow("network_policy")))
        assertEquals(250, settingsCursor.getInt(settingsCursor.getColumnIndexOrThrow("reserve_space_mb")))
        assertEquals(1, settingsCursor.getInt(settingsCursor.getColumnIndexOrThrow("fifo_rotation_enabled")))
        assertEquals(0, settingsCursor.getInt(settingsCursor.getColumnIndexOrThrow("allow_cloud_only_eviction")))
        assertEquals(1, settingsCursor.getInt(settingsCursor.getColumnIndexOrThrow("require_charging")))
        assertEquals(testTimestamp, settingsCursor.getLong(settingsCursor.getColumnIndexOrThrow("last_modified_timestamp")))
        settingsCursor.close()

        // 4. Verifica che i dati di exclusion_patterns siano rimasti intatti al 100%
        val patternsCursor = db.query("SELECT pattern, position FROM exclusion_patterns ORDER BY position ASC")
        assertEquals("Devono esserci 3 pattern", 3, patternsCursor.count)
        patternsCursor.moveToFirst()
        assertEquals("cache", patternsCursor.getString(0))
        assertEquals(0, patternsCursor.getInt(1))
        patternsCursor.moveToNext()
        assertEquals("*.tmp", patternsCursor.getString(0))
        assertEquals(1, patternsCursor.getInt(1))
        patternsCursor.moveToNext()
        assertEquals(".thumbnails", patternsCursor.getString(0))
        assertEquals(2, patternsCursor.getInt(1))
        patternsCursor.close()

        // 5. Verifica che la nuova tabella backup_folders esista e consenta inserimenti
        db.execSQL("""
            INSERT INTO backup_folders (id, tree_uri, display_name, authority, added_timestamp, priority, protect_from_eviction, enabled)
            VALUES ('folder-1', 'content://test.auth/tree/dcim', 'DCIM', 'test.auth', 123456789, 'ALTA', 1, 1)
        """.trimIndent())

        val folderCursor = db.query("SELECT * FROM backup_folders WHERE id = 'folder-1'")
        assertTrue(folderCursor.moveToFirst())
        assertEquals("folder-1", folderCursor.getString(folderCursor.getColumnIndexOrThrow("id")))
        assertEquals("content://test.auth/tree/dcim", folderCursor.getString(folderCursor.getColumnIndexOrThrow("tree_uri")))
        assertEquals("DCIM", folderCursor.getString(folderCursor.getColumnIndexOrThrow("display_name")))
        assertEquals("ALTA", folderCursor.getString(folderCursor.getColumnIndexOrThrow("priority")))
        assertEquals(1, folderCursor.getInt(folderCursor.getColumnIndexOrThrow("protect_from_eviction")))
        assertEquals(1, folderCursor.getInt(folderCursor.getColumnIndexOrThrow("enabled")))
        folderCursor.close()

        // 6. Verifica che l'indice univoco su tree_uri blocchi categoricamente inserimenti duplicati
        try {
            db.execSQL("""
                INSERT INTO backup_folders (id, tree_uri, display_name, authority, added_timestamp, priority, protect_from_eviction, enabled)
                VALUES ('folder-2', 'content://test.auth/tree/dcim', 'DCIM Duplicato', 'test.auth', 987654321, 'BASSA', 0, 1)
            """.trimIndent())
            fail("L'inserimento di un tree_uri duplicato deve fallire con SQLiteConstraintException a causa dell'indice univoco")
        } catch (e: SQLiteConstraintException) {
            assertTrue("Il vincolo di unicità ha impedito l'inserimento duplicato", true)
        }
    }

    @Test
    fun testMigratedDatabaseOpensSuccessfullyWithRoomAndDaosOperateNormally() = runBlocking {
        val testTimestamp = 1730005555555L

        // 1. Popola i dati v1 prima dell'apertura Room
        db.execSQL("""
            INSERT INTO app_settings (
                id, frequency, network_policy, reserve_space_mb,
                fifo_rotation_enabled, allow_cloud_only_eviction, require_charging, last_modified_timestamp
            ) VALUES (
                ${AppSettingsEntity.DEFAULT_ID}, 'TWELVE_HOURS', 'WIFI_ONLY', 500,
                0, 1, 0, $testTimestamp
            )
        """.trimIndent())

        db.execSQL("INSERT INTO exclusion_patterns (pattern, position) VALUES ('.git', 0)")
        db.execSQL("INSERT INTO exclusion_patterns (pattern, position) VALUES ('node_modules', 1)")

        // Chiude la connessione SQLite low-level per consentire l'apertura tramite Room
        db.close()
        openHelper.close()

        // 2. Apri il database migrato con Room runtime aggiungendo MIGRATION_1_2 (Point 3)
        val roomDb = Room.databaseBuilder(
            context,
            BackupDatabase::class.java,
            "test_migration.db"
        )
            .addMigrations(BackupDatabase.MIGRATION_1_2)
            .allowMainThreadQueries()
            .build()
        roomDatabase = roomDb

        // 3. Verifica lettura impostazioni v1 tramite SettingsDao
        val settings = roomDb.settingsDao().getSettings()
        assertNotNull("Le impostazioni devono essere lette dal SettingsDao", settings)
        assertEquals("TWELVE_HOURS", settings!!.frequency)
        assertEquals("WIFI_ONLY", settings.networkPolicy)
        assertEquals(500, settings.reserveSpaceMb)
        assertFalse(settings.fifoRotationEnabled)
        assertTrue(settings.allowCloudOnlyEviction)
        assertFalse(settings.requireCharging)
        assertEquals(testTimestamp, settings.lastModifiedTimestamp)

        // 4. Verifica lettura pattern v1 tramite SettingsDao
        val patterns = roomDb.settingsDao().getPatterns()
        assertEquals(2, patterns.size)
        assertEquals(".git", patterns[0].pattern)
        assertEquals("node_modules", patterns[1].pattern)

        // 5. Verifica inserimento e lettura cartella tramite FolderDao v2
        val folderEntity = BackupFolderEntity(
            id = "room-migrated-1",
            treeUri = "content://com.android.externalstorage.documents/tree/primary%3ARoomTest",
            displayName = "RoomTest",
            authority = "com.android.externalstorage.documents",
            addedTimestamp = System.currentTimeMillis(),
            priority = "ALTA",
            protectFromEviction = true,
            enabled = true
        )
        roomDb.folderDao().insertFolder(folderEntity)

        val retrievedFolders = roomDb.folderDao().getFolders()
        assertEquals(1, retrievedFolders.size)
        assertEquals("room-migrated-1", retrievedFolders[0].id)
        assertEquals("RoomTest", retrievedFolders[0].displayName)
        assertTrue(retrievedFolders[0].protectFromEviction)

        // 6. Verifica che l'indice univoco su tree_uri funzioni anche tramite Room DAO
        val duplicateFolder = BackupFolderEntity(
            id = "room-migrated-2",
            treeUri = "content://com.android.externalstorage.documents/tree/primary%3ARoomTest",
            displayName = "RoomTest Duplicato",
            authority = "com.android.externalstorage.documents",
            addedTimestamp = System.currentTimeMillis() + 100,
            priority = "BASSA",
            protectFromEviction = false,
            enabled = true
        )

        try {
            roomDb.folderDao().insertFolder(duplicateFolder)
            fail("L'inserimento di una cartella con tree_uri duplicato tramite DAO deve lanciare eccezione")
        } catch (e: SQLiteConstraintException) {
            assertTrue("Il vincolo di unicità è attivo e validato da Room", true)
        }

        // Il conteggio cartelle deve rimanere 1
        assertEquals(1, roomDb.folderDao().getFolders().size)
    }
}
