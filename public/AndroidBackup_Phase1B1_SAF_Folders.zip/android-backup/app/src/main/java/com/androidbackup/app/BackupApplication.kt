package com.androidbackup.app

import android.app.Application
import com.androidbackup.app.data.local.database.BackupDatabase
import com.androidbackup.app.data.repository.FolderRepository
import com.androidbackup.app.data.repository.SettingsRepository
import com.androidbackup.app.data.saf.AndroidSafPermissionManager
import com.androidbackup.app.data.saf.SafPermissionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Applicazione principale per Android Backup.
 *
 * Conforme alla Specifica Fase 1B.1:
 * - Inizializza istanze singleton di BackupDatabase, SettingsRepository e FolderRepository
 * - Non fa uso di framework complessi di dependency injection (no Hilt)
 * - Inizializza i valori predefiniti di Room in background senza bloccare il main thread
 * - Fornisce AndroidSafPermissionManager per l'acquisizione sicura di permessi in sola lettura
 */
class BackupApplication : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database: BackupDatabase by lazy {
        BackupDatabase.getInstance(this)
    }

    val settingsRepository: SettingsRepository by lazy {
        SettingsRepository(database.settingsDao())
    }

    val safPermissionManager: SafPermissionManager by lazy {
        AndroidSafPermissionManager(this)
    }

    val folderRepository: FolderRepository by lazy {
        FolderRepository(database.folderDao(), safPermissionManager)
    }

    override fun onCreate() {
        super.onCreate()

        // Inizializza le impostazioni predefinite solo se il database è appena stato creato
        applicationScope.launch {
            settingsRepository.initializeDefaultsIfEmpty()
        }
    }
}
