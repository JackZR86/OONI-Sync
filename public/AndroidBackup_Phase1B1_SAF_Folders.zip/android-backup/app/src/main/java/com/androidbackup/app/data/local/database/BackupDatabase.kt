package com.androidbackup.app.data.local.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.androidbackup.app.data.local.dao.FolderDao
import com.androidbackup.app.data.local.dao.SettingsDao
import com.androidbackup.app.data.local.entity.AppSettingsEntity
import com.androidbackup.app.data.local.entity.BackupFolderEntity
import com.androidbackup.app.data.local.entity.ExclusionPatternEntity

/**
 * Database Room principale per Android Backup.
 *
 * Vincoli architetturali Fase 1B.1:
 * - Versione 2 (migrazione incrementale da v1 tramite MIGRATION_1_2)
 * - File SQLite stabile: "android_backup.db"
 * - NESSUN allowMainThreadQueries() nell'ambiente di produzione
 * - NESSUN fallbackToDestructiveMigration()
 * - Preserva integralmente tutte le impostazioni ed esclusioni v1
 * - Nuova tabella backup_folders con indice univoco su tree_uri
 */
@Database(
    entities = [
        AppSettingsEntity::class,
        ExclusionPatternEntity::class,
        BackupFolderEntity::class
    ],
    version = 2,
    exportSchema = true
)
abstract class BackupDatabase : RoomDatabase() {

    abstract fun settingsDao(): SettingsDao
    abstract fun folderDao(): FolderDao

    companion object {
        const val DATABASE_NAME = "android_backup.db"

        @Volatile
        private var INSTANCE: BackupDatabase? = null

        /**
         * Migrazione esplicita dalla Versione 1 alla Versione 2.
         * Crea la nuova tabella `backup_folders` e l'indice univoco su `tree_uri`,
         * conservando integralmente le tabelle `app_settings` ed `exclusion_patterns`.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `backup_folders` (
                        `id` TEXT NOT NULL,
                        `tree_uri` TEXT NOT NULL,
                        `display_name` TEXT NOT NULL,
                        `authority` TEXT,
                        `added_timestamp` INTEGER NOT NULL,
                        `priority` TEXT NOT NULL,
                        `protect_from_eviction` INTEGER NOT NULL,
                        `enabled` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS `index_backup_folders_tree_uri` ON `backup_folders` (`tree_uri`)"
                )
            }
        }

        /**
         * Restituisce l'istanza singleton del database SQLite con migrazioni configurate.
         */
        fun getInstance(context: Context): BackupDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BackupDatabase::class.java,
                    DATABASE_NAME
                )
                    .addMigrations(MIGRATION_1_2)
                    // NOTA RIGOROSA: fallbackToDestructiveMigration() rimane espressamente escluso
                    .build()
                INSTANCE = instance
                instance
            }
        }

        /**
         * Crea un database in-memory per scopi di testing.
         */
        fun createInMemoryDatabase(context: Context): BackupDatabase {
            return Room.inMemoryDatabaseBuilder(
                context,
                BackupDatabase::class.java
            )
                .allowMainThreadQueries()
                .build()
        }
    }
}
