# Android Backup – Progetto Nativo Android (Kotlin + Jetpack Compose)

Questo archivio contiene l'intero progetto Android nativo aggiornato alla **Specifica Fase 1B.1 (Storage Access Framework e Persistenza delle Cartelle)**.

## Requisiti di compilazione:
- **Android Studio**: Iguana (2023.2.1) o successivo (Ladybug, Koala, Meerkat, Ladybug Feature Drop)
- **JDK**: 17 o 21 (configurato in *Project Structure > SDK Location > Gradle JDK*)
- **Gradle Wrapper**: 8.5 (incluso: `gradle-wrapper.jar`, `gradle-wrapper.properties`, `gradlew`, `gradlew.bat`)
- **Android Gradle Plugin (AGP)**: 8.3.1
- **Kotlin**: 2.0.0 (con plugin Compose compiler integrato e KAPT)
- **Room Persistence**: 2.6.1 (`room-runtime`, `room-ktx`, `room-compiler` via KAPT)
- **Min SDK**: 26 (Android 8.0 Oreo)
- **Target / Compile SDK**: 34 (Android 14)

## Istruzioni di apertura ed esecuzione:
1. Estrai questo archivio in una cartella locale a tua scelta (es. `~/AndroidStudioProjects/AndroidBackup`).
2. Apri Android Studio e seleziona **File > Open...**.
3. Seleziona la cartella principale del progetto estratto (quella contenente `settings.gradle.kts` e `build.gradle.kts`).
4. Attendi che Gradle Sync completi il download delle dipendenze e l'indicizzazione.
5. Per eseguire i test unitari: tasto destro sulla cartella `app/src/test/java` > **Run 'Tests in 'java''**.
6. Seleziona un emulatore o dispositivo fisico ed esegui **Run 'app'** (`:app:assembleDebug`).

## Componenti e Novità Fase 1B.1 (SAF e Cartelle):
- **Storage Access Framework (SAF)**:
  - Selezione sicura delle cartelle tramite `ActivityResultContracts.OpenDocumentTree()` / `ACTION_OPEN_DOCUMENT_TREE`.
  - Acquisizione permessi persistenti esclusivamente con `Intent.FLAG_GRANT_READ_URI_PERMISSION`.
  - Nessun permesso di scrittura, nessuna modifica/cancellazione dei file locali, nessuna operazione `File.delete()` o `DocumentFile.delete()`.
  - Nessun permesso pericoloso `MANAGE_EXTERNAL_STORAGE` o `READ_EXTERNAL_STORAGE`.
- **Database Room v2 e Migrazione non distruttiva (`MIGRATION_1_2`)**:
  - Tabella `backup_folders` con `id` (PK UUID), `tree_uri` (con indice UNIQUE), `display_name`, `authority`, `added_timestamp`, `priority`, `protect_from_eviction`, `enabled`.
  - Nessuna perdita di dati: conserva tutte le impostazioni e pattern della versione 1 (`app_settings`, `exclusion_patterns`).
- **Verifica permessi e accessibilità dinamica**:
  - `SafPermissionManager` e `AndroidSafPermissionManager`: interrogano `contentResolver.persistedUriPermissions`.
  - Al boot e al rientro, le cartelle revocate dall'utente a livello di sistema vengono contrassegnate con badge "Accesso non disponibile" senza essere cancellate da Room, consentendo la ri-selezione.
- **Cancellazione sicura in due fasi**:
  - La rimozione di una cartella dall'app rimuove prima il record da Room e poi rilascia il permesso persistente via `releasePersistableUriPermission`. I file originali dell'utente rimangono intatti al 100%.
- **Separazione rigorosa Demo / Reale**:
  - In modalità reale le cartelle SAF mostrano badge "Sola lettura" e "Scansione non ancora eseguita" (nessun conteggio o dimensione fittizia).
  - La scansione ricorsiva e i fingerprint SHA-256 sono rigorosamente demandati alla Fase 1B.2.
- **Suite di Test Completa**:
  - `FolderDaoTest`: test CRUD, indici univoci, flow e aggiornamenti su database SQLite in-memory reale.
  - `FolderRepositoryTest`: test autorizzazioni SAF persistenti, rifiuto duplicati, revoche e rimozione sicura con `FakeSafPermissionManager`.
  - `DatabaseMigrationTest`: test formale di `MIGRATION_1_2` con verifica integrità dati v1.
  - `RoomSettingsDaoTest`, `SettingsRepositoryTest`, `ExclusionPatternNormalizationTest`, `MockDataIsolationTest`.
