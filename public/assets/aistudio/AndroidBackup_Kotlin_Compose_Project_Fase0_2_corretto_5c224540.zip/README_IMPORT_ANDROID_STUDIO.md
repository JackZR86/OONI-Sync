# Android Backup – Progetto Nativo Android (Kotlin + Jetpack Compose)

Questo archivio contiene l'intero progetto Android nativo creato in conformità alla **Specifica 1.0 (Fase 0 – Scheletro e UI)**.

## Requisiti di compilazione:
- **Android Studio Iguana | 2023.2.1** o successivo (Ladybug, Koala, Meerkat)
- **JDK**: 17 o 21 (configurato in Project Structure > SDK Location > Gradle JDK)
- **Gradle Wrapper**: 8.5 (incluso: `gradle-wrapper.jar`, `gradle-wrapper.properties`, `gradlew`, `gradlew.bat`)
- **Android Gradle Plugin (AGP)**: 8.3.1
- **Kotlin**: 2.0.0 (con plugin Compose compiler integrato)
- **Min SDK**: 26 (Android 8.0 Oreo)
- **Target / Compile SDK**: 34 (Android 14)

## Istruzioni di apertura:
1. Estrai questo archivio in una cartella locale a tua scelta (es. `~/AndroidStudioProjects/AndroidBackup`).
2. Apri Android Studio e seleziona **File > Open...**.
3. Seleziona la cartella principale del progetto estratto (quella contenente `settings.gradle.kts` e `build.gradle.kts`).
4. Attendi che Gradle Sync completi il download delle dipendenze.
5. Seleziona un emulatore o dispositivo fisico ed esegui **Run 'app'**.

## Componenti inclusi:
- **Gradle Wrapper 8.5 Completo**: `gradle/wrapper/gradle-wrapper.jar` (con `org.gradle.wrapper.GradleWrapperMain`), `gradle/wrapper/gradle-wrapper.properties`, `gradlew` (chmod +x) e `gradlew.bat`.
- **Single Activity**: `MainActivity.kt` con Compose Edge-to-Edge.
- **Componenti riutilizzabili**: `BackupComponents.kt` (`BackupStatusCard`, `GoogleStorageCard`, `FolderCard`, `HistoryCard`, `LogItemCard`, `StatusBadge`, `StatColumn`).
- **Schermate**: `HomeScreen.kt`, `FoldersScreen.kt`, `RulesScreen.kt`, `HistoryScreen.kt`, `LogScreen.kt`.
- **Navigation Compose**: `NavHost.kt` e `Screen.kt`.
- **Material 3**: Tema chiaro/scuro e supporto Dynamic Color in `ui/theme/`.
- **MVVM StateFlow**: `BackupViewModel.kt` con gestione stato e regole.
- **Separazione Mock Trasparente**: Dati fittizi isolati in `MockDataProvider.kt` con banner DEMO visibile.
- **Sicurezza**: Backup strettamente unidirezionale verso Google Drive; nessun file locale viene mai modificato o rimosso.
