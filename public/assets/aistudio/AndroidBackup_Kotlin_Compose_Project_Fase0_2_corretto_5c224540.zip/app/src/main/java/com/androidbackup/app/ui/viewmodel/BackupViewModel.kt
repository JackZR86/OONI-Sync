package com.androidbackup.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.androidbackup.app.data.mock.MockDataProvider
import com.androidbackup.app.data.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Stato della UI dell'applicazione Android Backup (Fase 0)
 */
data class BackupUiState(
    val status: BackupStatus = BackupStatus.COMPLETATO,
    val lastBackupTimestamp: String? = "5 Nov 2026, 09:15",
    val nextEstimatedBackupTime: String = "Domani, 09:15 (stimato WorkManager)",
    val backupProgress: Float = 0f,
    val currentOperationMessage: String? = null,
    val folders: List<BackupSource> = MockDataProvider.demoFolders,
    val rules: AppSettings = AppSettings(),
    val quota: GoogleStorageQuota = MockDataProvider.demoQuota,
    val history: List<BackupRun> = MockDataProvider.demoHistory,
    val logs: List<BackupLog> = MockDataProvider.demoLogs,
    val selectedLogLevel: LogLevel? = null, // null = TUTTI
    val logSearchQuery: String = "",
    val isDemoMode: Boolean = true,
    val isAddFolderDialogOpen: Boolean = false,
    val isFifoWarningDialogOpen: Boolean = false
)

class BackupViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(BackupUiState())
    val uiState: StateFlow<BackupUiState> = _uiState.asStateFlow()

    private var simulationJob: Job? = null

    /**
     * Alterna la modalità Dati Dimostrativi con dati mock espliciti
     */
    fun toggleDemoMode(enableDemo: Boolean) {
        if (enableDemo) {
            _uiState.update {
                it.copy(
                    isDemoMode = true,
                    status = BackupStatus.COMPLETATO,
                    lastBackupTimestamp = "5 Nov 2026, 09:15",
                    nextEstimatedBackupTime = "Domani, 09:15 (stimato WorkManager)",
                    folders = MockDataProvider.demoFolders,
                    quota = MockDataProvider.demoQuota,
                    history = MockDataProvider.demoHistory,
                    logs = MockDataProvider.demoLogs
                )
            }
        } else {
            // Torna allo stato scheletro vuoto iniziale
            _uiState.update {
                it.copy(
                    isDemoMode = false,
                    status = BackupStatus.INATTIVO,
                    lastBackupTimestamp = null,
                    nextEstimatedBackupTime = "Non pianificato (Nessuna cartella configurata)",
                    folders = emptyList(),
                    quota = GoogleStorageQuota(usedBytes = 0L, isMock = true),
                    history = emptyList(),
                    logs = listOf(
                        BackupLog(
                            id = "init-empty",
                            timestamp = SimpleDateFormat("HH:mm:ss", Locale.ITALIAN).format(Date()),
                            level = LogLevel.INFO,
                            category = "SISTEMA",
                            message = "Applicazione inizializzata in stato vuoto. Nessuna operazione o cartella configurata.",
                            technicalCode = "INIT_SKELETON_EMPTY"
                        )
                    )
                )
            }
        }
    }

    /**
     * Imposta manualmente lo stato per testare visivamente tutti gli stati richiesti:
     * (Inattivo, In attesa, In corso, Completato, Parziale, Errore)
     */
    fun setBackupStatus(status: BackupStatus) {
        _uiState.update { it.copy(status = status) }
    }

    /**
     * Simula il processo di backup (solo UI state chiaramente identificato come simulazione)
     */
    fun startBackupSimulation() {
        if (_uiState.value.status == BackupStatus.IN_CORSO) return

        simulationJob?.cancel()
        simulationJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    status = BackupStatus.IN_CORSO,
                    backupProgress = 0.05f,
                    currentOperationMessage = "SIMULAZIONE: Verifica vincoli di rete (Wi-Fi)..."
                )
            }
            delay(800)

            _uiState.update {
                it.copy(
                    backupProgress = 0.35f,
                    currentOperationMessage = "SIMULAZIONE: Scansione ricorsiva cartelle e fingerprint SHA-256..."
                )
            }
            delay(1000)

            _uiState.update {
                it.copy(
                    backupProgress = 0.75f,
                    currentOperationMessage = "SIMULAZIONE: Verifica quote e simulazione caricamento verso Drive..."
                )
            }
            delay(1200)

            val nowFormatted = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.ITALIAN).format(Date())
            val simulatedRun = BackupRun(
                id = "sim-${System.currentTimeMillis()}",
                timestamp = "$nowFormatted (Simulato)",
                durationSeconds = 3,
                status = BackupStatus.COMPLETATO,
                filesChecked = _uiState.value.folders.sumOf { it.fileCount }.coerceAtLeast(10),
                filesUploaded = 3,
                filesSkipped = (_uiState.value.folders.sumOf { it.fileCount } - 3).coerceAtLeast(7),
                bytesUploaded = 15L * 1024 * 1024,
                bytesFreed = 0L,
                triggerType = "SIMULAZIONE UI",
                notes = "[SIMULAZIONE DIMOSTRATIVA] Esecuzione di prova UI. Nessun file locale o su Google Drive è stato modificato."
            )

            val simulatedLog = BackupLog(
                id = "log-sim-${System.currentTimeMillis()}",
                timestamp = SimpleDateFormat("HH:mm:ss", Locale.ITALIAN).format(Date()),
                level = LogLevel.INFO,
                category = "SISTEMA",
                message = "Simulazione di backup completata con successo nella UI.",
                technicalCode = "SIMULATION_SUCCESS"
            )

            _uiState.update {
                it.copy(
                    backupProgress = 1.0f,
                    status = BackupStatus.COMPLETATO,
                    currentOperationMessage = null,
                    lastBackupTimestamp = "$nowFormatted (Simulato)",
                    nextEstimatedBackupTime = "Fra circa 24 ore (stimato WorkManager)",
                    history = listOf(simulatedRun) + it.history,
                    logs = listOf(simulatedLog) + it.logs
                )
            }
        }
    }

    fun cancelBackupSimulation() {
        simulationJob?.cancel()
        _uiState.update {
            it.copy(
                status = BackupStatus.INATTIVO,
                backupProgress = 0f,
                currentOperationMessage = null
            )
        }
    }

    fun addFolder(name: String, path: String, priority: Priority, protectFromEviction: Boolean) {
        val newFolder = BackupSource(
            id = UUID.randomUUID().toString(),
            name = name.ifBlank { "Nuova Cartella Dimostrativa" },
            path = path.ifBlank { "/storage/emulated/0/" },
            priority = priority,
            protectFromEviction = protectFromEviction,
            fileCount = 0,
            totalSizeMb = 0,
            lastScanned = "Mai"
        )
        _uiState.update { it.copy(folders = it.folders + newFolder) }
    }

    fun removeFolder(id: String) {
        _uiState.update { it.copy(folders = it.folders.filter { f -> f.id != id }) }
    }

    fun updateFolderPriority(id: String, newPriority: Priority) {
        _uiState.update {
            it.copy(
                folders = it.folders.map { f ->
                    if (f.id == id) f.copy(priority = newPriority) else f
                }
            )
        }
    }

    fun toggleFolderProtection(id: String) {
        _uiState.update {
            it.copy(
                folders = it.folders.map { f ->
                    if (f.id == id) f.copy(protectFromEviction = !f.protectFromEviction) else f
                }
            )
        }
    }

    fun updateFrequency(frequency: BackupFrequency) {
        _uiState.update { it.copy(rules = it.rules.copy(frequency = frequency)) }
    }

    fun updateNetworkPolicy(policy: NetworkPolicy) {
        _uiState.update { it.copy(rules = it.rules.copy(networkPolicy = policy)) }
    }

    fun setFifoEnabled(enabled: Boolean) {
        _uiState.update { it.copy(rules = it.rules.copy(fifoRotationEnabled = enabled)) }
    }

    fun setRequireCharging(enabled: Boolean) {
        _uiState.update { it.copy(rules = it.rules.copy(requireCharging = enabled)) }
    }

    fun setAllowCloudOnlyEviction(enabled: Boolean) {
        _uiState.update { it.copy(rules = it.rules.copy(allowCloudOnlyEviction = enabled)) }
    }

    fun setReserveSpace(mb: Int) {
        _uiState.update { it.copy(rules = it.rules.copy(reserveSpaceMb = mb)) }
    }

    fun addExclusionPattern(pattern: String) {
        val cleanPattern = pattern.trim()
        if (cleanPattern.isEmpty()) return
        _uiState.update { state ->
            if (state.rules.exclusions.contains(cleanPattern)) {
                state
            } else {
                state.copy(rules = state.rules.copy(exclusions = state.rules.exclusions + cleanPattern))
            }
        }
    }

    fun removeExclusionPattern(pattern: String) {
        _uiState.update {
            it.copy(rules = it.rules.copy(exclusions = it.rules.exclusions.filter { p -> p != pattern }))
        }
    }

    fun setLogLevelFilter(level: LogLevel?) {
        _uiState.update { it.copy(selectedLogLevel = level) }
    }

    fun setLogSearchQuery(query: String) {
        _uiState.update { it.copy(logSearchQuery = query) }
    }
}
