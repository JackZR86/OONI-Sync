# Android Backup – Progetto Nativo Android (Kotlin + Jetpack Compose)

Questo archivio contiene l'intero progetto Android nativo aggiornato alla **Specifica Fase 01A (Room e persistenza delle impostazioni)**.

## Requisiti di compilazione:
- **Android Studio**: Iguana (2023.2.1) o successivo (Ladybug, Koala, Meerkat, Ladybug Feature Drop)
- **JDK**: 17 o 21 (configurato in *Project Structure > SDK Location > Gradle JDK*)
- **Gradle Wrapper**: 8.5 (incluso: `gradle-wrapper.jar`, `gradle-wrapper.properties`, `gradlew`, `gradlew.bat`)
- **Android Gradle Plugin (AGP)**: 8.3.1
- **Kotlin**: 2.0.0 (con plugin Compose compiler integrato e KAPT)
- **Room Persistence**: 2.6.1 (`room-runtime`, `room-ktx`, `room-compiler` via KAPT)
- **Min SDK**: 26 (Android 8.0 Oreo)
- **Target / Compile SDK**: 34 (Android 14)

## Istruzioni di apertura ed esecuzione:
1. Estrai questo archivio in una cartella locale a tua scelta (es. `~/AndroidStudioProjects/AndroidBackup`).
2. Apri Android Studio e seleziona **File > Open...**.
3. Seleziona la cartella principale del progetto estratto (quella contenente `settings.gradle.kts` e `build.gradle.kts`).
4. Attendi che Gradle Sync completi il download delle dipendenze e l'indicizzazione.
5. Per eseguire i test unitari: tasto destro sulla cartella `app/src/test/java` > **Run 'Tests in 'java''**.
6. Seleziona un emulatore o dispositivo fisico ed esegui **Run 'app'** (`:app:assembleDebug`).

## Componenti e Novità Fase 01A:
- **Room Persistence 2.6.1**: Database SQLite locale `android_backup.db` versione 1.
- **Entità persistenti**:
  - `AppSettingsEntity`: Configurazione globale (frequenza, policy rete, riserva spazio, vincolo ricarica, rotazione FIFO, cloud-only eviction) con gestione sicura dei fallback enum.
  - `ExclusionPatternEntity`: Pattern di esclusione ordinati per posizione, con chiave primaria univoca per evitare duplicati e normalizzazione `trim()`.
- **DAO reattivo (`SettingsDao`)**: Query con `Flow`, metodi asincroni `suspend` e salvataggi atomici con `@Transaction`.
- **Repository (`SettingsRepository`)**: Punto unico di accesso per il ViewModel, combinazione dei flussi, inizializzazione predefinita non distruttiva e propagazione esplicita degli errori via `Result<Unit>`.
- **Application Container (`BackupApplication`)**: Registrato nel Manifest (`android:name=".BackupApplication"`), inizializza il singleton e popola i valori predefiniti solo se il database è vuoto.
- **ViewModel Factory (`BackupViewModelFactory`)**: Inietta in sicurezza `SettingsRepository` in `BackupViewModel` senza framework complessi di DI.
- **Separazione rigorosa Mock/DB**: Dati dimostrativi (`MockDataProvider`) completamente esclusi dal database Room; i cambi di stato demo non sovrascrivono le regole reali.
- **Sicurezza**: Nessun permesso pericoloso aggiunto (né rete, né file storage); nessun `allowMainThreadQueries()`; nessun `fallbackToDestructiveMigration()`.
