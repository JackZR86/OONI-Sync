package com.androidbackup.app

import android.app.Application
import com.androidbackup.app.data.local.database.BackupDatabase
import com.androidbackup.app.data.repository.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Applicazione principale per Android Backup.
 *
 * Conforme alla Specifica Fase 01A:
 * - Inizializza una singola istanza singleton di BackupDatabase e SettingsRepository
 * - Non fa uso di framework complessi di dependency injection (no Hilt)
 * - Inizializza i valori predefiniti di Room in background senza bloccare il main thread
 */
class BackupApplication : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database: BackupDatabase by lazy {
        BackupDatabase.getInstance(this)
    }

    val settingsRepository: SettingsRepository by lazy {
        SettingsRepository(database.settingsDao())
    }

    override fun onCreate() {
        super.onCreate()

        // Inizializza le impostazioni predefinite solo se il database è appena stato creato
        applicationScope.launch {
            settingsRepository.initializeDefaultsIfEmpty()
        }
    }
}
