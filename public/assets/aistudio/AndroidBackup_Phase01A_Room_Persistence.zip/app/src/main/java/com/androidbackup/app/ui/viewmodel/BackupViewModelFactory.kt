package com.androidbackup.app.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.androidbackup.app.BackupApplication
import com.androidbackup.app.data.repository.SettingsRepository

/**
 * Factory per creare l'istanza di [BackupViewModel] iniettando il repository persistente [SettingsRepository].
 * Conforme alla Specifica Fase 01A:
 * - Evita framework complessi di DI
 * - Garantisce che il ViewModel acceda a Room esclusivamente tramite il Repository
 */
class BackupViewModelFactory(
    private val repository: SettingsRepository
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(BackupViewModel::class.java)) {
            return BackupViewModel(repository) as T
        }
        throw IllegalArgumentException("Classe ViewModel non supportata: ${modelClass.name}")
    }

    companion object {
        /**
         * Crea la factory a partire dall'application context
         */
        fun provideFactory(context: Context): BackupViewModelFactory {
            val app = context.applicationContext as? BackupApplication
                ?: throw IllegalStateException("L'Application context deve essere un'istanza di BackupApplication")
            return BackupViewModelFactory(app.settingsRepository)
        }
    }
}
