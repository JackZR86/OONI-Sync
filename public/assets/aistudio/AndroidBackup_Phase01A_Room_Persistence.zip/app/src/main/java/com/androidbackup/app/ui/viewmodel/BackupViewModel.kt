package com.androidbackup.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.androidbackup.app.data.mock.MockDataProvider
import com.androidbackup.app.data.model.*
import com.androidbackup.app.data.repository.SettingsRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Stato della UI dell'applicazione Android Backup (Fase 01A)
 */
data class BackupUiState(
    val status: BackupStatus = BackupStatus.COMPLETATO,
    val lastBackupTimestamp: String? = "5 Nov 2026, 09:15",
    val nextEstimatedBackupTime: String = "Domani, 09:15 (stimato WorkManager)",
    val backupProgress: Float = 0f,
    val currentOperationMessage: String? = null,
    val folders: List<BackupSource> = MockDataProvider.demoFolders,
    val rules: AppSettings = AppSettings(),
    val quota: GoogleStorageQuota = MockDataProvider.demoQuota,
    val history: List<BackupRun> = MockDataProvider.demoHistory,
    val logs: List<BackupLog> = MockDataProvider.demoLogs,
    val selectedLogLevel: LogLevel? = null, // null = TUTTI
    val logSearchQuery: String = "",
    val isDemoMode: Boolean = true,
    val isAddFolderDialogOpen: Boolean = false,
    val isFifoWarningDialogOpen: Boolean = false
)

/**
 * ViewModel principale per Android Backup con integrazione persistenza Room via SettingsRepository.
 * Conforme alla Specifica Fase 01A:
 * - Osserva le impostazioni persistite tramite StateFlow/Flow
 * - Aggiorna immediatamente la UI e persiste le modifiche in background
 * - Isola rigorosamente i dati dimostrativi: i mock NON vengono salvati nel DB
 * - I cambi di modalità demo non sovrascrivono mai le impostazioni salvate
 * - Gestisce gli errori di salvataggio senza bloccare l'app e registrandoli nei log
 */
class BackupViewModel(
    private val repository: SettingsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(BackupUiState())
    val uiState: StateFlow<BackupUiState> = _uiState.asStateFlow()

    private var simulationJob: Job? = null

    init {
        // Osserva costantemente le impostazioni reali dal repository Room
        viewModelScope.launch {
            repository.settingsFlow.collect { persistentRules ->
                _uiState.update { it.copy(rules = persistentRules) }
            }
        }
    }

    /**
     * Alterna la modalità Dati Dimostrativi con dati mock espliciti.
     * NOTA FASE 01A: Le impostazioni reali (rules) NON vengono toccate o sovrascritte da mock.
     */
    fun toggleDemoMode(enableDemo: Boolean) {
        if (enableDemo) {
            _uiState.update {
                it.copy(
                    isDemoMode = true,
                    status = BackupStatus.COMPLETATO,
                    lastBackupTimestamp = "5 Nov 2026, 09:15",
                    nextEstimatedBackupTime = "Domani, 09:15 (stimato WorkManager)",
                    folders = MockDataProvider.demoFolders,
                    quota = MockDataProvider.demoQuota,
                    history = MockDataProvider.demoHistory,
                    logs = MockDataProvider.demoLogs
                    // rules rimane invariato, preservando le impostazioni reali persistite in Room
                )
            }
        } else {
            // Torna allo stato scheletro vuoto iniziale
            _uiState.update {
                it.copy(
                    isDemoMode = false,
                    status = BackupStatus.INATTIVO,
                    lastBackupTimestamp = null,
                    nextEstimatedBackupTime = "Non pianificato (Nessuna cartella configurata)",
                    folders = emptyList(),
                    quota = GoogleStorageQuota(usedBytes = 0L, isMock = true),
                    history = emptyList(),
                    logs = listOf(
                        BackupLog(
                            id = "init-empty",
                            timestamp = SimpleDateFormat("HH:mm:ss", Locale.ITALIAN).format(Date()),
                            level = LogLevel.INFO,
                            category = "SISTEMA",
                            message = "Applicazione inizializzata in stato vuoto. Dati dimostrativi disattivati.",
                            technicalCode = "INIT_SKELETON_EMPTY"
                        )
                    )
                    // rules rimane invariato, preservando le impostazioni reali persistite in Room
                )
            }
        }
    }

    /**
     * Imposta manualmente lo stato per testare visivamente tutti gli stati richiesti:
     * (Inattivo, In attesa, In corso, Completato, Parziale, Errore)
     */
    fun setBackupStatus(status: BackupStatus) {
        _uiState.update { it.copy(status = status) }
    }

    /**
     * Simula il processo di backup (solo UI state chiaramente identificato come simulazione)
     */
    fun startBackupSimulation() {
        if (_uiState.value.status == BackupStatus.IN_CORSO) return

        simulationJob?.cancel()
        simulationJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    status = BackupStatus.IN_CORSO,
                    backupProgress = 0.05f,
                    currentOperationMessage = "SIMULAZIONE: Verifica vincoli di rete (Wi-Fi)..."
                )
            }
            delay(800)

            _uiState.update {
                it.copy(
                    backupProgress = 0.35f,
                    currentOperationMessage = "SIMULAZIONE: Scansione ricorsiva cartelle e fingerprint SHA-256..."
                )
            }
            delay(1000)

            _uiState.update {
                it.copy(
                    backupProgress = 0.75f,
                    currentOperationMessage = "SIMULAZIONE: Verifica quote e simulazione caricamento verso Drive..."
                )
            }
            delay(1200)

            val nowFormatted = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.ITALIAN).format(Date())
            val simulatedRun = BackupRun(
                id = "sim-${System.currentTimeMillis()}",
                timestamp = "$nowFormatted (Simulato)",
                durationSeconds = 3,
                status = BackupStatus.COMPLETATO,
                filesChecked = _uiState.value.folders.sumOf { it.fileCount }.coerceAtLeast(10),
                filesUploaded = 3,
                filesSkipped = (_uiState.value.folders.sumOf { it.fileCount } - 3).coerceAtLeast(7),
                bytesUploaded = 15L * 1024 * 1024,
                bytesFreed = 0L,
                triggerType = "SIMULAZIONE UI",
                notes = "[SIMULAZIONE DIMOSTRATIVA] Esecuzione di prova UI. Nessun file locale o su Google Drive è stato modificato."
            )

            val simulatedLog = BackupLog(
                id = "log-sim-${System.currentTimeMillis()}",
                timestamp = SimpleDateFormat("HH:mm:ss", Locale.ITALIAN).format(Date()),
                level = LogLevel.INFO,
                category = "SISTEMA",
                message = "Simulazione di backup completata con successo nella UI.",
                technicalCode = "SIMULATION_SUCCESS"
            )

            _uiState.update {
                it.copy(
                    backupProgress = 1.0f,
                    status = BackupStatus.COMPLETATO,
                    currentOperationMessage = null,
                    lastBackupTimestamp = "$nowFormatted (Simulato)",
                    nextEstimatedBackupTime = "Fra circa 24 ore (stimato WorkManager)",
                    history = listOf(simulatedRun) + it.history,
                    logs = listOf(simulatedLog) + it.logs
                )
            }
        }
    }

    fun cancelBackupSimulation() {
        simulationJob?.cancel()
        _uiState.update {
            it.copy(
                status = BackupStatus.INATTIVO,
                backupProgress = 0f,
                currentOperationMessage = null
            )
        }
    }

    fun addFolder(name: String, path: String, priority: Priority, protectFromEviction: Boolean) {
        val newFolder = BackupSource(
            id = UUID.randomUUID().toString(),
            name = name.ifBlank { "Nuova Cartella Dimostrativa" },
            path = path.ifBlank { "/storage/emulated/0/" },
            priority = priority,
            protectFromEviction = protectFromEviction,
            fileCount = 0,
            totalSizeMb = 0,
            lastScanned = "Mai"
        )
        _uiState.update { it.copy(folders = it.folders + newFolder) }
    }

    fun removeFolder(id: String) {
        _uiState.update { it.copy(folders = it.folders.filter { f -> f.id != id }) }
    }

    fun updateFolderPriority(id: String, newPriority: Priority) {
        _uiState.update {
            it.copy(
                folders = it.folders.map { f ->
                    if (f.id == id) f.copy(priority = newPriority) else f
                }
            )
        }
    }

    fun toggleFolderProtection(id: String) {
        _uiState.update {
            it.copy(
                folders = it.folders.map { f ->
                    if (f.id == id) f.copy(protectFromEviction = !f.protectFromEviction) else f
                }
            )
        }
    }

    // ==========================================
    // GESTIONE REGOLE E PERSISTENZA ROOM (Fase 01A)
    // ==========================================

    fun updateFrequency(frequency: BackupFrequency) {
        _uiState.update { it.copy(rules = it.rules.copy(frequency = frequency)) }
        viewModelScope.launch {
            repository.updateFrequency(frequency).onFailure { error ->
                logPersistenceError("Salvataggio frequenza non riuscito: ${error.localizedMessage}")
            }
        }
    }

    fun updateNetworkPolicy(policy: NetworkPolicy) {
        _uiState.update { it.copy(rules = it.rules.copy(networkPolicy = policy)) }
        viewModelScope.launch {
            repository.updateNetworkPolicy(policy).onFailure { error ->
                logPersistenceError("Salvataggio policy di rete non riuscito: ${error.localizedMessage}")
            }
        }
    }

    fun setRequireCharging(enabled: Boolean) {
        _uiState.update { it.copy(rules = it.rules.copy(requireCharging = enabled)) }
        viewModelScope.launch {
            repository.updateRequireCharging(enabled).onFailure { error ->
                logPersistenceError("Salvataggio vincolo ricarica non riuscito: ${error.localizedMessage}")
            }
        }
    }

    fun setFifoEnabled(enabled: Boolean) {
        _uiState.update { it.copy(rules = it.rules.copy(fifoRotationEnabled = enabled)) }
        viewModelScope.launch {
            repository.updateFifoRotation(enabled).onFailure { error ->
                logPersistenceError("Salvataggio rotazione FIFO non riuscito: ${error.localizedMessage}")
            }
        }
    }

    fun setAllowCloudOnlyEviction(enabled: Boolean) {
        _uiState.update { it.copy(rules = it.rules.copy(allowCloudOnlyEviction = enabled)) }
        viewModelScope.launch {
            repository.updateCloudOnlyEviction(enabled).onFailure { error ->
                logPersistenceError("Salvataggio rimozione cloud-only non riuscito: ${error.localizedMessage}")
            }
        }
    }

    fun setReserveSpace(mb: Int) {
        _uiState.update { it.copy(rules = it.rules.copy(reserveSpaceMb = mb)) }
        viewModelScope.launch {
            repository.updateReserveSpace(mb).onFailure { error ->
                logPersistenceError("Salvataggio riserva spazio non riuscito: ${error.localizedMessage}")
            }
        }
    }

    fun addExclusionPattern(pattern: String) {
        val cleanPattern = pattern.trim()
        if (cleanPattern.isEmpty()) return
        if (_uiState.value.rules.exclusions.contains(cleanPattern)) return

        _uiState.update { state ->
            state.copy(rules = state.rules.copy(exclusions = state.rules.exclusions + cleanPattern))
        }
        viewModelScope.launch {
            repository.addExclusionPattern(cleanPattern).onFailure { error ->
                logPersistenceError("Aggiunta pattern '$cleanPattern' non riuscita: ${error.localizedMessage}")
            }
        }
    }

    fun removeExclusionPattern(pattern: String) {
        _uiState.update {
            it.copy(rules = it.rules.copy(exclusions = it.rules.exclusions.filter { p -> p != pattern }))
        }
        viewModelScope.launch {
            repository.removeExclusionPattern(pattern).onFailure { error ->
                logPersistenceError("Rimozione pattern '$pattern' non riuscita: ${error.localizedMessage}")
            }
        }
    }

    fun clearAllExclusions() {
        _uiState.update {
            it.copy(rules = it.rules.copy(exclusions = emptyList()))
        }
        viewModelScope.launch {
            repository.clearAllExclusions().onFailure { error ->
                logPersistenceError("Cancellazione di tutte le esclusioni non riuscita: ${error.localizedMessage}")
            }
        }
    }

    fun resetRulesToDefaults() {
        viewModelScope.launch {
            repository.resetToDefaults().onFailure { error ->
                logPersistenceError("Ripristino impostazioni predefinite non riuscito: ${error.localizedMessage}")
            }
        }
    }

    private fun logPersistenceError(message: String) {
        val errorLog = BackupLog(
            id = "err-db-${System.currentTimeMillis()}",
            timestamp = SimpleDateFormat("HH:mm:ss", Locale.ITALIAN).format(Date()),
            level = LogLevel.ERRORE,
            category = "DATABASE",
            message = message,
            technicalCode = "ROOM_PERSISTENCE_ERROR"
        )
        _uiState.update { it.copy(logs = listOf(errorLog) + it.logs) }
    }

    fun setLogLevelFilter(level: LogLevel?) {
        _uiState.update { it.copy(selectedLogLevel = level) }
    }

    fun setLogSearchQuery(query: String) {
        _uiState.update { it.copy(logSearchQuery = query) }
    }
}
