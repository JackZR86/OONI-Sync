package com.androidbackup.app.data.local.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.androidbackup.app.data.local.dao.SettingsDao
import com.androidbackup.app.data.local.entity.AppSettingsEntity
import com.androidbackup.app.data.local.entity.ExclusionPatternEntity

/**
 * Database Room principale per Android Backup.
 *
 * Vincoli architetturali Fase 01A:
 * - Versione 1
 * - File SQLite stabile: "android_backup.db"
 * - NESSUN allowMainThreadQueries()
 * - NESSUN fallbackToDestructiveMigration()
 * - Predisposto per migrazioni esplicite future (es. MIGRATION_1_2)
 */
@Database(
    entities = [
        AppSettingsEntity::class,
        ExclusionPatternEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class BackupDatabase : RoomDatabase() {

    abstract fun settingsDao(): SettingsDao

    companion object {
        const val DATABASE_NAME = "android_backup.db"

        @Volatile
        private var INSTANCE: BackupDatabase? = null

        /**
         * Restituisce l'istanza singleton del database SQLite.
         */
        fun getInstance(context: Context): BackupDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BackupDatabase::class.java,
                    DATABASE_NAME
                )
                    // NOTA RIGOROSA: Non abilitiamo fallbackToDestructiveMigration().
                    // Tutte le modifiche future di schema devono essere gestite con migrazioni esplicite:
                    // .addMigrations(MIGRATION_1_2)
                    .build()
                INSTANCE = instance
                instance
            }
        }

        /**
         * Crea un database in-memory per scopi di testing.
         */
        fun createInMemoryDatabase(context: Context): BackupDatabase {
            return Room.inMemoryDatabaseBuilder(
                context,
                BackupDatabase::class.java
            )
                .allowMainThreadQueries() // Consentito esclusivamente nei test isolati
                .build()
        }
    }
}
